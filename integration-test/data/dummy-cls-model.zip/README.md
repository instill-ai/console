---
Task: Classification
Tags:
  - Classification
  - Test
---

# Test repo
This is dummy classification model used for testing purpose